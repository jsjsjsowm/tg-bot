# -*- coding: utf-8 -*-
"""
Schedule data for E-24 group, 2nd year, 1st semester
"""

SCHEDULE = {
    "monday": [
        {"time": "8:30-9:50", "subject": "Фізична культура", "pair_number": 1},
        {"time": "10:00-11:20", "subject": "Географія/Зарубіжна література", "pair_number": 2},
        {"time": "12:00-13:20", "subject": "Громадянська освіта", "pair_number": 3},
        {"time": "13:30-14:50", "subject": "Історія України/Всесвітня Історія", "pair_number": 4}
    ],
    "tuesday": [
        {"time": "8:30-9:50", "subject": "Захист України", "pair_number": 1},
        {"time": "10:00-11:20", "subject": "Хімія/Біологія і екологія", "pair_number": 2},
        {"time": "12:00-13:20", "subject": "Математика", "pair_number": 3},
        {"time": "13:30-14:50", "subject": "Основи програмування", "pair_number": 4}
    ],
    "wednesday": [
        {"time": "8:30-9:50", "subject": "Українська мова", "pair_number": 1},
        {"time": "10:00-11:20", "subject": "Теорія електричних та магнітних кіл", "pair_number": 2},
        {"time": "12:00-13:20", "subject": "Українська література", "pair_number": 3}
    ],
    "thursday": [
        {"time": "8:30-9:50", "subject": "Технології/Комп'ютерна графіка", "pair_number": 1},
        {"time": "10:00-11:20", "subject": "Інформатика", "pair_number": 2},
        {"time": "12:00-13:20", "subject": "Основи програмування/ТЕ та МК", "pair_number": 3}
    ],
    "friday": [
        {"time": "8:30-9:50", "subject": "Іноземна мова/Фізика і астрономія", "pair_number": 1},
        {"time": "10:00-11:20", "subject": "Фізика і астрономія", "pair_number": 2},
        {"time": "12:00-13:20", "subject": "Математика", "pair_number": 3},
        {"time": "13:30-14:50", "subject": "Фізична культура", "pair_number": 4}
    ]
}

# Break schedule
BREAK_SCHEDULE = [
    {"time": "8:30-9:50", "break_after": "9:50-10:00"},
    {"time": "10:00-11:20", "break_after": "11:20-12:00"},
    {"time": "12:00-13:20", "break_after": "13:20-13:30"},
    {"time": "13:30-14:50", "break_after": "після занять"}
]

WEEKDAYS = {
    0: "monday",
    1: "tuesday", 
    2: "wednesday",
    3: "thursday",
    4: "friday",
    5: "saturday",
    6: "sunday"
}

WEEKDAYS_UA = {
    "monday": "Понеділок",
    "tuesday": "Вівторок",
    "wednesday": "Середа", 
    "thursday": "Четвер",
    "friday": "П'ятниця",
    "saturday": "Субота",
    "sunday": "Неділя"
}
