# -*- coding: utf-8 -*-
"""
Telegram Bot for E-24 Schedule Management
Supports both private messages and group chats
"""

import os
import logging
from datetime import datetime, time
from typing import Optional
import pytz
from telegram import Update, BotCommand
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from flask import Flask, jsonify, render_template_string
import threading
from schedule_data import SCHEDULE, WEEKDAYS, WEEKDAYS_UA, BREAK_SCHEDULE

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Bot configuration
BOT_TOKEN = os.getenv('BOT_TOKEN')
WEBHOOK_URL = os.getenv('WEBHOOK_URL')
PORT = int(os.getenv('PORT', 5000))

# Ukraine timezone
UKRAINE_TZ = pytz.timezone('Europe/Kiev')

# Bot activity tracking
bot_stats = {
    'start_time': datetime.now(UKRAINE_TZ),
    'messages_processed': 0,
    'active_chats': set(),
    'last_activity': datetime.now(UKRAINE_TZ)
}

class ScheduleBot:
    def __init__(self):
        self.application = None
        
    def get_current_time_ukraine(self) -> datetime:
        """Get current time in Ukraine timezone"""
        return datetime.now(UKRAINE_TZ)
    
    def get_current_day(self) -> str:
        """Get current day of week"""
        current_time = self.get_current_time_ukraine()
        return WEEKDAYS.get(current_time.weekday(), 'sunday')
    
    def parse_time(self, time_str: str) -> tuple:
        """Parse time string like '8:30-9:50' to start and end time objects"""
        start_str, end_str = time_str.split('-')
        start_hour, start_min = map(int, start_str.split(':'))
        end_hour, end_min = map(int, end_str.split(':'))
        
        start_time = time(start_hour, start_min)
        end_time = time(end_hour, end_min)
        
        return start_time, end_time
    
    def get_current_pair(self) -> Optional[dict]:
        """Get currently active pair"""
        current_day = self.get_current_day()
        current_time = self.get_current_time_ukraine().time()
        
        if current_day not in SCHEDULE:
            return None
            
        for pair in SCHEDULE[current_day]:
            start_time, end_time = self.parse_time(pair['time'])
            if start_time <= current_time <= end_time:
                return pair
        
        return None
    
    def get_next_pair(self) -> Optional[dict]:
        """Get next upcoming pair"""
        current_day = self.get_current_day()
        current_time = self.get_current_time_ukraine().time()
        
        if current_day not in SCHEDULE:
            return None
            
        for pair in SCHEDULE[current_day]:
            start_time, _ = self.parse_time(pair['time'])
            if current_time < start_time:
                return pair
        
        return None
    
    def get_today_schedule(self) -> list:
        """Get today's full schedule"""
        current_day = self.get_current_day()
        return SCHEDULE.get(current_day, [])
    
    def format_schedule_day(self, day: str, pairs: list) -> str:
        """Format schedule for a specific day"""
        if not pairs:
            return f"📅 **{WEEKDAYS_UA[day]}**: Вихідний день"
        
        result = f"📅 **{WEEKDAYS_UA[day]}**:\n"
        for pair in pairs:
            result += f"🕐 {pair['time']} - {pair['subject']}\n"
        
        return result
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        bot_stats['messages_processed'] += 1
        bot_stats['active_chats'].add(update.effective_chat.id)
        bot_stats['last_activity'] = self.get_current_time_ukraine()
        
        welcome_text = """
🎓 **Привіт! Я бот розкладу групи E-24**

📚 **Доступні команди:**
/schedule - Показати повний розклад на тиждень
/current - Яка пара зараз йде
/next - Яка наступна пара
/today - Розклад на сьогодні
/help - Показати це повідомлення

🕐 Бот працює за київським часом та автоматично відстежує поточні пари.
        """
        
        await update.message.reply_text(welcome_text, parse_mode='Markdown')
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        await self.start_command(update, context)
    
    async def schedule_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /schedule command - show full week schedule"""
        bot_stats['messages_processed'] += 1
        bot_stats['last_activity'] = self.get_current_time_ukraine()
        
        result = "📋 **Розклад групи E-24 (2 курс, 1 семестр)**\n\n"
        
        for day_key, day_name in WEEKDAYS_UA.items():
            if day_key in SCHEDULE:
                result += self.format_schedule_day(day_key, SCHEDULE[day_key]) + "\n\n"
        
        await update.message.reply_text(result, parse_mode='Markdown')
    
    async def current_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /current command - show current pair"""
        bot_stats['messages_processed'] += 1
        bot_stats['last_activity'] = self.get_current_time_ukraine()
        
        current_pair = self.get_current_pair()
        current_time = self.get_current_time_ukraine()
        
        if current_pair:
            result = f"🔴 **Зараз йде пара:**\n"
            result += f"📚 {current_pair['subject']}\n"
            result += f"🕐 {current_pair['time']}\n"
            result += f"📊 Пара #{current_pair['pair_number']}"
        else:
            result = f"✅ **Зараз перерва або вихідний**\n"
            result += f"🕐 Поточний час: {current_time.strftime('%H:%M')}\n"
            
            next_pair = self.get_next_pair()
            if next_pair:
                result += f"⏭️ Наступна пара: {next_pair['subject']} о {next_pair['time'].split('-')[0]}"
        
        await update.message.reply_text(result, parse_mode='Markdown')
    
    async def next_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /next command - show next pair"""
        bot_stats['messages_processed'] += 1
        bot_stats['last_activity'] = self.get_current_time_ukraine()
        
        next_pair = self.get_next_pair()
        
        if next_pair:
            result = f"⏭️ **Наступна пара:**\n"
            result += f"📚 {next_pair['subject']}\n"
            result += f"🕐 {next_pair['time']}\n"
            result += f"📊 Пара #{next_pair['pair_number']}"
        else:
            result = f"✅ **Сьогодні більше пар немає**\n"
            result += f"🎉 Можна відпочивати!"
        
        await update.message.reply_text(result, parse_mode='Markdown')
    
    async def today_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /today command - show today's schedule"""
        bot_stats['messages_processed'] += 1
        bot_stats['last_activity'] = self.get_current_time_ukraine()
        
        today_schedule = self.get_today_schedule()
        current_day = self.get_current_day()
        
        if not today_schedule:
            result = f"🎉 **Сьогодні ({WEEKDAYS_UA[current_day]}) вихідний день!**"
        else:
            result = f"📅 **Розклад на сьогодні ({WEEKDAYS_UA[current_day]}):**\n\n"
            
            current_pair = self.get_current_pair()
            current_time = self.get_current_time_ukraine().time()
            
            for pair in today_schedule:
                start_time, end_time = self.parse_time(pair['time'])
                
                if current_pair and pair == current_pair:
                    status = "🔴 ЗАРАЗ"
                elif current_time < start_time:
                    status = "⏳ БУДЕ"
                else:
                    status = "✅ БУЛО"
                
                result += f"{status} {pair['time']} - {pair['subject']}\n"
        
        await update.message.reply_text(result, parse_mode='Markdown')
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle regular messages"""
        bot_stats['messages_processed'] += 1
        bot_stats['active_chats'].add(update.effective_chat.id)
        bot_stats['last_activity'] = self.get_current_time_ukraine()
        
        message_text = update.message.text.lower()
        
        if any(word in message_text for word in ['розклад', 'пари', 'schedule']):
            await self.schedule_command(update, context)
        elif any(word in message_text for word in ['зараз', 'поточна', 'current']):
            await self.current_command(update, context)
        elif any(word in message_text for word in ['наступна', 'next']):
            await self.next_command(update, context)
        elif any(word in message_text for word in ['сьогодні', 'today']):
            await self.today_command(update, context)
        else:
            await update.message.reply_text(
                "Використовуйте /help для перегляду доступних команд 📚"
            )
    
    async def setup_bot(self):
        """Setup bot with commands and handlers"""
        # Set bot commands
        commands = [
            BotCommand("start", "Запустити бота"),
            BotCommand("schedule", "Повний розклад"),
            BotCommand("current", "Поточна пара"),
            BotCommand("next", "Наступна пара"),
            BotCommand("today", "Розклад на сьогодні"),
            BotCommand("help", "Допомога")
        ]
        
        await self.application.bot.set_my_commands(commands)
        
        # Add handlers
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("schedule", self.schedule_command))
        self.application.add_handler(CommandHandler("current", self.current_command))
        self.application.add_handler(CommandHandler("next", self.next_command))
        self.application.add_handler(CommandHandler("today", self.today_command))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
    
    async def run_webhook(self):
        """Run bot with webhook"""
        self.application = Application.builder().token(BOT_TOKEN).build()
        await self.setup_bot()
        
        # Set webhook
        await self.application.bot.set_webhook(
            url=f"{WEBHOOK_URL}/webhook",
            allowed_updates=["message", "callback_query"]
        )
        
        # Start webhook
        await self.application.run_webhook(
            listen="0.0.0.0",
            port=PORT,
            webhook_url=f"{WEBHOOK_URL}/webhook",
            secret_token="your_secret_token_here"
        )

# Flask app for status page
app = Flask(__name__)

@app.route('/')
def status():
    """Bot status page"""
    current_time = datetime.now(UKRAINE_TZ)
    uptime = current_time - bot_stats['start_time']
    
    status_html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>E-24 Schedule Bot Status</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .status { padding: 20px; border-radius: 5px; margin: 20px 0; }
            .online { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
            .offline { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
            .stat { margin: 10px 0; padding: 10px; background: #f8f9fa; border-radius: 5px; }
            h1 { color: #333; text-align: center; }
            .emoji { font-size: 1.2em; }
        </style>
        <script>
            setTimeout(function(){ location.reload(); }, 30000);
        </script>
    </head>
    <body>
        <div class="container">
            <h1>🎓 E-24 Schedule Bot Status</h1>
            
            <div class="status online">
                <h2>🟢 Bot is Online</h2>
                <p>The schedule bot is running and ready to help!</p>
            </div>
            
            <div class="stat">
                <strong>📊 Statistics:</strong><br>
                🚀 Started: {{ start_time }}<br>
                ⏱️ Uptime: {{ uptime }}<br>
                💬 Messages processed: {{ messages_processed }}<br>
                👥 Active chats: {{ active_chats }}<br>
                🕐 Last activity: {{ last_activity }}
            </div>
            
            <div class="stat">
                <strong>🇺🇦 Current Ukraine Time:</strong><br>
                {{ current_time }}
            </div>
            
            <div class="stat">
                <strong>📚 Available Commands:</strong><br>
                /start - Start the bot<br>
                /schedule - Full week schedule<br>
                /current - Current class<br>
                /next - Next class<br>
                /today - Today's schedule<br>
                /help - Show help
            </div>
            
            <p style="text-align: center; color: #666; margin-top: 30px;">
                Page auto-refreshes every 30 seconds
            </p>
        </div>
    </body>
    </html>
    """
    
    return render_template_string(status_html,
        start_time=bot_stats['start_time'].strftime('%Y-%m-%d %H:%M:%S'),
        uptime=str(uptime).split('.')[0],
        messages_processed=bot_stats['messages_processed'],
        active_chats=len(bot_stats['active_chats']),
        last_activity=bot_stats['last_activity'].strftime('%Y-%m-%d %H:%M:%S'),
        current_time=current_time.strftime('%Y-%m-%d %H:%M:%S')
    )

@app.route('/api/status')
def api_status():
    """API endpoint for bot status"""
    current_time = datetime.now(UKRAINE_TZ)
    uptime = current_time - bot_stats['start_time']
    
    return jsonify({
        'status': 'online',
        'start_time': bot_stats['start_time'].isoformat(),
        'uptime_seconds': int(uptime.total_seconds()),
        'messages_processed': bot_stats['messages_processed'],
        'active_chats': len(bot_stats['active_chats']),
        'last_activity': bot_stats['last_activity'].isoformat(),
        'current_time': current_time.isoformat()
    })

def run_flask():
    """Run Flask app in separate thread"""
    app.run(host='0.0.0.0', port=PORT, debug=False)

if __name__ == '__main__':
    if not BOT_TOKEN:
        print("❌ BOT_TOKEN environment variable is required!")
        exit(1)
    
    if not WEBHOOK_URL:
        print("❌ WEBHOOK_URL environment variable is required!")
        exit(1)
    
    # Start Flask in separate thread
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    
    # Start bot
    bot = ScheduleBot()
    import asyncio
    asyncio.run(bot.run_webhook())
